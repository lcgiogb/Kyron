function iniciarAnalise() {
    navigator.mediaDevices.getUserMedia({
        video: true
    })
    .then(function(stream) {
        videoElement.srcObject = stream;
        videoElement.style.display = "block";
    })
    .catch(function(erro) {
        alert("Não foi possível acessar a câmera.");
        console.log(erro);
    });
}